#!/bin/bash
ctags -R --sort=1 --c++-kinds=+p --fields=+ialS --extra=+q --language-force=c++ .
